library;

String name = "";
String age = "";
String height = "";
String weight = "";
String uid = "";
bool isConnected = false;
bool isConnecting = false;
